RPGXP/RPGVX SGEdit
Edit RPGXP/RPGVX saved game files like Aveyond or Aveyond 2. The program
uses configuration files that can be created or modified to work with any
other game built with RPG Maker XP v1.02a or RPG Maker VX v1.02.

You can take a look at "example.ini" to understand how you can make your
own or change configuration files, since I've not yet added the possibility
of editing these files you have to do all the work, just use a text editor
like notepad. Instead of opening a file, you can drop it on the application
window, this is valid for both saved games and configuration files. The
default configuration is for Aveyond, to override this behavior rename the
desired configuration file for the same name as the application executable
(sgedit.exe = sgedit.ini), you can test it with one of the configuration
files distributed with SGEdit.

Added Game.ini template for Excel made by Austin Fischer

Before you ask I must inform that only the main character of the game can
be edited at this time.

Known unsupported games:
Laxius Force (1)
3 Stars of Destiny (1)
Laxius Party (2)
Laxius Force II (2)

(1) Laxius Force series use the sgeditlf.exe instead
(2) Not supported by both versions of sgedit

Navigation Keys:
Ctrl+O  - Open file
Ctrl+S  - Save file
Ctrl+A  - Save file with another name
Ctrl+C  - Close file
Ctrl+X  - Exit program
Ctrl+L  - Load game configuration
Ctrl+1  - Select party tab
Ctrl+2  - Select player tab
Ctrl+3  - Select switch tab
F5      - Reload current opened file
Ctrl+F5 - Reload current configuration file
F8      - Create snapshot of the switches
F9      - Search for changed switches

Item Keys:
This keys are only available after you select an item in item list
Beside the normal navigation keys like UP, DOWN, LEFT, RIGHT, PAGE UP,
PAGE DOWN, etc..., you can use the following keys:
Shift+'NUMPAD +' - Set maximum item amount
Shift+'NUMPAD -' - Set item amount to zero (delete item)

Switches Keys:
Left mouse double-click will do the same as Space key
Space  - Set switch (unset,false,true)
Ctrl+N - Unset switch
Ctrl+F - Set switch to false
Ctrl+T - Set switch to true

Tips:
Instead of browsing for a file, just drop the file in the main window.
This is valid for all files that can be open by the application,
including configuration files (*.ini). To reload the current opened file
press the F5 key, the same can be done when you have changed a
configuration file just press CTRL + F5 keys to reload.
There's a menu that can be used when changing a switch, just press the
right mouse button when the cursor is over an item and the menu will pop.
The adjust bar located in the player tab can also be controlled by the
keyboard, UP, DOWN, PAGE UP, PAGE DOWN, HOME and END. There is a
possibility to take a snapshot of the switches (press F8 or click on "S"
button and select "Create snapshot" item from the menu that pops when the
button "S" is pressed) then either select "Search for changes" from the
"S" button menu or press F9 to search for changed switches, in case a
window is displayed it will have the previous values of the changed
switches or if a new switch is found is also added to that list.

License:  
THE USAGE AND/OR DISTRIBUTION OF THIS SOFTWARE IMPLIES THE ACCEPTANCE
OF THE FOLLOWING TERMS:

(1) THIS SOFTWARE IS PROVIDED 'AS-IS', WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY (HAS NO WARRANTY OF ANY KIND), USE IT AT YOUR OWN RISK.
(2) THIS SOFTWARE MAY ONLY BE DISTRIBUTED FREE OF CHARGE, ALL THE FILES
MUST BE PRESENT AND HAVE NOT BEEN MODIFIED, INCLUDING THIS DOCUMENT WITH
THE EXCEPTION OF THE CONFIGURATION FILES, YOU ARE FREE TO CHANGE THEM.

IF YOU DO NOT AGREE WITH ANY OF THESE TERMS DO NOT USE AND/OR DO NOT
DISTRIBUTE THIS SOFTWARE.

Contact:
darklunas@gmail.com
