﻿This file was downloaded from: http://www.dll-files.com


If you downloaded it from somewhere else, please let us know: http://www.dll-files.com/contact.php 



Installation instructions: 



Extract the .dll file from .zip file. We recommend that you extract the .dll to the installation directory of the program that is requesting the .dll.

If that doesn't work, you will have to extract the .dll to your system directory. By default, this is:
C:\Windows\System (Windows 95/98/Me)
C:\WINNT\System32 (Windows NT/2000)
C:\Windows\System32 (Windows XP, Vista, 7, win 8)
If you use a 64-bit version of Windows, you should also place the .dll in C:\Windows\SysWOW64\
Make sure to overwrite any existing files (but make a backup copy of the original file for safety).
Reboot your computer.

If the problem still occurs, try the following:
Open Windows Start menu and select "Run...".
Type CMD and press Enter (or if you use Windows ME, type COMMAND)).
Type regsvr32 <filename>.dll and press Enter.

If you have any other problems, see our HELP-section at www.dll-files.com/support/


Hope this helps!

Regards from the DLL-Files.com Team
